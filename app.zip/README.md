# rag-chatbot
Azure OpenAI + Cognitive Search による社内文書検索チャットボット
